<?php
    session_start();
    error_reporting(0);

    $host ='localhost';
    $user = 'webhozzt_fauzan';
    $pass = 'fauzan0203';
    $db   = 'webhozzt_fauzan_shidqi';
    $con  = mysqli_connect($host,$user,$pass,$db);


?>